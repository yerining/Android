package com.example.flashlight

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Switch

class MainActivity : AppCompatActivity() {

    lateinit var flashSwitch : Switch //플래시

    //음악 서비스
    lateinit var soundIntent: Intent
    lateinit var btnStart: Button
    lateinit var btnStop: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //플래시
        flashSwitch = findViewById(R.id.flashSwitch)
        val torch = Torch(this)
        val intent = Intent(this,TorchService::class.java)

        flashSwitch.setOnCheckedChangeListener { buttonView, isChecked ->
            if(isChecked){
                //torch.flashOn()
                intent.action = "on"
                startService(intent) //intent를 보냄
            } else{
                //torch.flashOff()
                intent.action = "off"
                startService(intent)
            }
        }

        //음악 서비스
        soundIntent = Intent(this,MusicService::class.java)
        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)

        btnStart.setOnClickListener {
            startService(soundIntent)
            Log.i("서비스 테스트","startService()")
        }

        btnStop.setOnClickListener {
            stopService(soundIntent)
            Log.i("서비스 테스트","stopService()")
        }
    }
}