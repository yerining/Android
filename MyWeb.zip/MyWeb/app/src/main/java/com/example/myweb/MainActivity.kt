package com.example.myweb

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    lateinit var webView: WebView
    lateinit var urlEditText: EditText
    lateinit var backButton: Button
    lateinit var forwardButton: Button
    lateinit var site: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlEditText = findViewById(R.id.urlEditText)
        webView = findViewById(R.id.webView)

        backButton = findViewById(R.id.backButton)
        forwardButton = findViewById(R.id.forwardButton)

        // 웹 뷰 기본 설정
        webView.apply {
            settings.javaScriptEnabled = true
            webViewClient = WebViewClient() //웹뷰 실행
        }

        webView.loadUrl("http://www.google.com")
        site="http://www.google.com"

        urlEditText.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH){
                webView.loadUrl(urlEditText.text.toString())
                site = urlEditText.text.toString() //사이트 저장
                true
            } else{
                false
            }
        }

        //컨텍스트 메뉴 등록
        registerForContextMenu(webView)

        //뒤로 가기
        backButton.setOnClickListener {
            webView.goBack()
        }

        //앞으로 가기
        forwardButton.setOnClickListener {
            webView.goForward()
        }
    }

    override fun onBackPressed() {
        if (webView.canGoBack()){
            webView.goBack()
        }else{
            super.onBackPressed()
        }
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?,
                                     menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context, menu)
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true //액티비티 메뉴 유무 판단
    }

    // 클릭시 동작 구현
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.action_reload -> {
                webView.reload()
                return true
            }
            R.id.action_google, R.id.action_home -> {
                webView.loadUrl("http://google.com")
                return true
            }

            R.id.action_naver -> {
                webView.loadUrl("http://www.naver.com")
                return true
            }

            R.id.action_daum ->{
                webView.loadUrl("http://www.daum.com")
                return true
            }

            //암시적 인텐트 연동
            R.id.action_call -> {
                val intent = Intent(Intent.ACTION_DIAL)
                intent.data = Uri.parse("tel:031-123-4567")
                if (intent.resolveActivity(packageManager) != null){
                    startActivity(intent)
                }

                return true
            }

            R.id.action_send_text -> {
                val intent = Intent(Intent.ACTION_SENDTO)
                intent.data = Uri.parse("smsto" + Uri.encode("012-3456-7890"))
                if (intent.resolveActivity(packageManager) != null){
                    startActivity(intent)
                }
                return true
            }

            R.id.action_email -> {
                val intent = Intent(Intent.ACTION_SENDTO)
                intent.data = Uri.parse("mailto: example@example.com")
                if(intent.resolveActivity(packageManager) != null){
                    startActivity(intent)
                }
                return true
            }

        }

        return super.onOptionsItemSelected(item)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when (item?.itemId){

            R.id.action_share -> {
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_TEXT, webView.url.toString())
                val shareIntent = Intent.createChooser(intent, "공유 페이지")
                startActivity(shareIntent)
                return true
            }

            R.id.action_browser -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webView.url))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
        }
        return super.onContextItemSelected(item)
    }

}

