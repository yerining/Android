package com.example.xylophone

import android.content.pm.ActivityInfo
import android.media.SoundPool
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.annotation.RequiresApi


// 실로폰은 가로모드만 가능
class MainActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private val soundPool = SoundPool.Builder().setMaxStreams(8).build()
    private val sounds = listOf(
        Pair(R.id.do1, R.raw.do1),
        Pair(R.id.re, R.raw.re),
        Pair(R.id.mi, R.raw.mi),
        Pair(R.id.pa, R.raw.fa),
        Pair(R.id.sol, R.raw.sol),
        Pair(R.id.ra, R.raw.la),
        Pair(R.id.si, R.raw.si),
        Pair(R.id.do2, R.raw.do2)
    )

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        //화면이 가로 모드로 고정되게 하기 : 첫 번째 방법
        //requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sounds.forEach{turn(it)}
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    private fun turn(pair: Pair<Int, Int>) {
        val soundId = soundPool?.load(this,pair.second,1)
        findViewById<TextView>(pair.first).setOnClickListener {
            if (soundId != null) {
                soundPool.play(soundId,1.0f,1.0f,0,0,1.0f)
            } //rate 재생속도
        }
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun onDestroy() {
        super.onDestroy()
        soundPool.release()
    }
}

